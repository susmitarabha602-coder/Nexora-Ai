import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Send, Bot, User, Sparkles, Cpu, Globe, Code } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import type { ChatMessage } from '../lib/supabase';

const SUGGESTIONS = [
  { icon: Sparkles, text: 'Explain quantum computing in simple terms' },
  { icon: Code, text: 'Write a Python function to sort a list' },
  { icon: Globe, text: 'Summarize the latest trends in AI' },
  { icon: Cpu, text: 'How does a neural network learn?' },
];

const AI_RESPONSES = [
  "That's a fascinating question! Based on current research and developments, I can provide a comprehensive analysis. The key aspects to consider are the underlying mechanisms, practical implications, and future potential of this topic.",
  "Great point! Let me break this down systematically. First, we need to understand the foundational principles at play here. The interaction between these elements creates a complex but ultimately understandable system.",
  "Excellent question! This touches on some of the most exciting developments in modern technology. The short answer is yes, but the nuances are what make it truly interesting.",
  "I'd be happy to help with that! Here's a detailed explanation: The core concept revolves around emergent behavior in complex systems, where simple rules give rise to sophisticated outcomes.",
  "Absolutely! This is something I find particularly interesting. The key insight here is that seemingly disparate elements are actually connected through deeper patterns and relationships.",
];

function getAiResponse(prompt: string): string {
  const idx = Math.floor(Math.random() * AI_RESPONSES.length);
  return AI_RESPONSES[idx] + `\n\nRegarding "${prompt.slice(0, 50)}..." - this is a simulated response. Connect a real AI API to get actual intelligent responses.`;
}

export function ChatPage() {
  const { conversationId } = useParams();
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (conversationId) {
      setLoadingHistory(true);
      supabase.from('chat_messages').select('*').eq('conversation_id', conversationId).order('created_at')
        .then(({ data: msgs }) => {
          if (msgs) setMessages(msgs);
          setLoadingHistory(false);
        });
    } else {
      setMessages([]);
    }
  }, [conversationId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  async function sendMessage(text: string) {
    if (!text.trim() || loading || !user) return;
    setLoading(true);

    let convId = conversationId;

    if (!convId) {
      const title = text.slice(0, 60);
      const { data: newConv } = await supabase
        .from('chat_conversations')
        .insert({ user_id: user.id, title })
        .select()
        .single();
      if (newConv) {
        convId = newConv.id;
        navigate(`/chat/${convId}`, { replace: true });
      }
    }

    if (!convId) { setLoading(false); return; }

    const userMsg: Partial<ChatMessage> = { conversation_id: convId, role: 'user', content: text };
    const { data: savedUser } = await supabase.from('chat_messages').insert(userMsg).select().single();
    if (savedUser) setMessages(prev => [...prev, savedUser]);
    setInput('');

    // Simulate AI thinking
    await new Promise(r => setTimeout(r, 800 + Math.random() * 600));
    const aiContent = getAiResponse(text);
    const { data: savedAi } = await supabase.from('chat_messages').insert({
      conversation_id: convId,
      role: 'assistant',
      content: aiContent,
    }).select().single();
    if (savedAi) setMessages(prev => [...prev, savedAi]);

    // Update conversation timestamp
    await supabase.from('chat_conversations').update({ updated_at: new Date().toISOString() }).eq('id', convId);

    setLoading(false);
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  }

  const isEmpty = messages.length === 0 && !loadingHistory;

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg-base)', position: 'relative' }}>
      {/* Background glow */}
      <div style={{ position: 'absolute', top: '20%', left: '50%', transform: 'translateX(-50%)', width: 600, height: 300, background: 'radial-gradient(ellipse, rgba(0,212,255,0.03) 0%, transparent 70%)', pointerEvents: 'none' }} />

      {/* Messages */}
      <div style={{ flex: 1, overflow: 'auto', padding: '24px 16px' }}>
        {loadingHistory ? (
          <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 60 }}>
            <div style={{ width: 32, height: 32, border: '2px solid var(--border)', borderTopColor: 'var(--accent-primary)', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
          </div>
        ) : isEmpty ? (
          <div style={{ maxWidth: 640, margin: '0 auto', paddingTop: 40, animation: 'fade-in 0.5s ease' }}>
            {/* Welcome */}
            <div style={{ textAlign: 'center', marginBottom: 48 }}>
              <div style={{
                width: 64, height: 64, borderRadius: 20, margin: '0 auto 20px',
                background: 'linear-gradient(135deg, rgba(0,212,255,0.15), rgba(0,153,204,0.08))',
                border: '1px solid rgba(0,212,255,0.2)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                boxShadow: '0 0 30px var(--accent-glow)',
                animation: 'float 4s ease-in-out infinite',
              }}>
                <Bot size={32} color="var(--accent-primary)" />
              </div>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 8 }}>
                Hello, {profile?.username ?? 'there'}!
              </h2>
              <p style={{ color: 'var(--text-secondary)', fontSize: 15 }}>
                How can I assist you today? Ask me anything.
              </p>
            </div>

            {/* Suggestions */}
            <div className="chat-suggestions-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
              {SUGGESTIONS.map(({ icon: Icon, text }) => (
                <button
                  key={text}
                  onClick={() => sendMessage(text)}
                  style={{
                    padding: '14px 16px',
                    background: 'var(--bg-surface)',
                    border: '1px solid var(--border)',
                    borderRadius: 'var(--radius-lg)',
                    color: 'var(--text-secondary)',
                    fontSize: 13,
                    textAlign: 'left',
                    transition: 'all var(--transition)',
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: 10,
                  }}
                  onMouseEnter={e => {
                    const el = e.currentTarget;
                    el.style.borderColor = 'rgba(0,212,255,0.3)';
                    el.style.background = 'var(--bg-elevated)';
                    el.style.color = 'var(--text-primary)';
                    el.style.boxShadow = '0 0 16px var(--accent-glow)';
                  }}
                  onMouseLeave={e => {
                    const el = e.currentTarget;
                    el.style.borderColor = 'var(--border)';
                    el.style.background = 'var(--bg-surface)';
                    el.style.color = 'var(--text-secondary)';
                    el.style.boxShadow = 'none';
                  }}
                >
                  <Icon size={15} color="var(--accent-primary)" style={{ flexShrink: 0, marginTop: 1 }} />
                  {text}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div style={{ maxWidth: 720, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 20 }}>
            {messages.map((msg, i) => (
              <div
                key={msg.id}
                style={{
                  display: 'flex',
                  gap: 12,
                  flexDirection: msg.role === 'user' ? 'row-reverse' : 'row',
                  animation: `fade-in 0.3s ease ${i * 0.05}s both`,
                }}
              >
                {/* Avatar */}
                <div style={{
                  width: 34,
                  height: 34,
                  borderRadius: '50%',
                  flexShrink: 0,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  background: msg.role === 'user'
                    ? 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))'
                    : 'linear-gradient(135deg, rgba(0,255,136,0.2), rgba(0,200,100,0.1))',
                  border: msg.role === 'assistant' ? '1px solid rgba(0,255,136,0.3)' : 'none',
                  boxShadow: msg.role === 'assistant' ? '0 0 12px var(--accent-green-glow)' : 'none',
                }}>
                  {msg.role === 'user' ? <User size={16} color="#000" /> : <Bot size={16} color="var(--accent-green)" />}
                </div>

                {/* Bubble */}
                <div style={{
                  maxWidth: '75%',
                  padding: '12px 16px',
                  borderRadius: msg.role === 'user' ? '18px 6px 18px 18px' : '6px 18px 18px 18px',
                  background: msg.role === 'user'
                    ? 'linear-gradient(135deg, rgba(0,212,255,0.15), rgba(0,153,204,0.1))'
                    : 'var(--bg-surface)',
                  border: msg.role === 'user'
                    ? '1px solid rgba(0,212,255,0.2)'
                    : '1px solid var(--border)',
                  color: 'var(--text-primary)',
                  fontSize: 14,
                  lineHeight: 1.6,
                  whiteSpace: 'pre-wrap',
                }}>
                  {msg.content}
                </div>
              </div>
            ))}

            {/* AI typing indicator */}
            {loading && (
              <div style={{ display: 'flex', gap: 12, animation: 'fade-in 0.3s ease' }}>
                <div style={{ width: 34, height: 34, borderRadius: '50%', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, rgba(0,255,136,0.2), rgba(0,200,100,0.1))', border: '1px solid rgba(0,255,136,0.3)', boxShadow: '0 0 12px var(--accent-green-glow)' }}>
                  <Bot size={16} color="var(--accent-green)" />
                </div>
                <div style={{ padding: '12px 16px', borderRadius: '6px 18px 18px 18px', background: 'var(--bg-surface)', border: '1px solid var(--border)', display: 'flex', gap: 6, alignItems: 'center' }}>
                  {[0, 0.2, 0.4].map((delay, i) => (
                    <div key={i} style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--accent-primary)', animation: `blink 1.2s ease-in-out ${delay}s infinite` }} />
                  ))}
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>
        )}
      </div>

      {/* Input area */}
      <div style={{
        padding: '16px',
        borderTop: '1px solid var(--border)',
        background: 'var(--bg-surface)',
        backdropFilter: 'blur(12px)',
      }}>
        <div style={{ maxWidth: 720, margin: '0 auto', position: 'relative' }}>
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask Nexora anything..."
            rows={1}
            style={{
              width: '100%',
              padding: '14px 56px 14px 16px',
              background: 'var(--bg-elevated)',
              border: '1px solid var(--border-bright)',
              borderRadius: 'var(--radius-lg)',
              color: 'var(--text-primary)',
              fontSize: 15,
              outline: 'none',
              resize: 'none',
              maxHeight: 160,
              overflow: 'auto',
              transition: 'border-color var(--transition), box-shadow var(--transition)',
              lineHeight: 1.5,
            }}
            onFocus={e => {
              e.target.style.borderColor = 'var(--accent-primary)';
              e.target.style.boxShadow = '0 0 0 3px var(--accent-glow)';
            }}
            onBlur={e => {
              e.target.style.borderColor = 'var(--border-bright)';
              e.target.style.boxShadow = 'none';
            }}
          />
          <button
            onClick={() => sendMessage(input)}
            disabled={!input.trim() || loading}
            style={{
              position: 'absolute',
              right: 10,
              bottom: 10,
              width: 36,
              height: 36,
              borderRadius: 10,
              background: input.trim() && !loading ? 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))' : 'var(--bg-card)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all var(--transition)',
              boxShadow: input.trim() && !loading ? '0 0 14px var(--accent-glow)' : 'none',
            }}
          >
            <Send size={16} color={input.trim() && !loading ? '#000' : 'var(--text-muted)'} />
          </button>
        </div>
        <p style={{ textAlign: 'center', fontSize: 11, color: 'var(--text-muted)', marginTop: 8 }}>
          Press Enter to send · Shift+Enter for new line
        </p>
      </div>
    </div>
  );
}
