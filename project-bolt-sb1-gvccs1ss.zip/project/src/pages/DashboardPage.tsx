import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Image, Zap, TrendingUp, Clock, ArrowRight, Activity } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';

export function DashboardPage() {
  const { user, profile } = useAuth();
  const [stats, setStats] = useState({ chats: 0, messages: 0, images: 0 });
  const [recentActivity, setRecentActivity] = useState<{ type: string; text: string; time: string }[]>([]);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      supabase.from('chat_conversations').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
      supabase.from('chat_messages').select('id', { count: 'exact', head: true }).eq('conversation_id', user.id),
      supabase.from('generated_images').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
      supabase.from('chat_conversations').select('title, created_at').eq('user_id', user.id).order('created_at', { ascending: false }).limit(3),
      supabase.from('generated_images').select('prompt, created_at').eq('user_id', user.id).order('created_at', { ascending: false }).limit(3),
    ]).then(([convs, msgs, imgs, recentConvs, recentImgs]) => {
      setStats({
        chats: convs.count ?? 0,
        messages: msgs.count ?? 0,
        images: imgs.count ?? 0,
      });

      const activity = [
        ...((recentConvs.data ?? []).map(c => ({ type: 'chat', text: c.title, time: c.created_at }))),
        ...((recentImgs.data ?? []).map(i => ({ type: 'image', text: i.prompt, time: i.created_at }))),
      ].sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime()).slice(0, 5);
      setRecentActivity(activity);
    });
  }, [user]);

  const planColor = profile?.plan === 'pro' ? 'var(--accent-green)' : profile?.plan === 'enterprise' ? 'var(--accent-amber)' : 'var(--accent-primary)';
  const creditsPercent = Math.min(100, ((profile?.credits ?? 0) / 10) * 100);

  const statCards = [
    { label: 'Conversations', value: stats.chats, icon: MessageSquare, color: 'var(--accent-primary)', glow: 'var(--accent-glow)' },
    { label: 'Images Created', value: stats.images, icon: Image, color: 'var(--accent-green)', glow: 'var(--accent-green-glow)' },
    { label: 'AI Credits Left', value: profile?.credits ?? 0, icon: Zap, color: 'var(--accent-amber)', glow: 'rgba(255,170,0,0.15)' },
    { label: 'Active Since', value: profile ? new Date(profile.created_at).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : '—', icon: Clock, color: 'var(--text-secondary)', glow: 'transparent' },
  ];

  const quickActions = [
    { icon: MessageSquare, label: 'New Chat', desc: 'Start a conversation', to: '/chat', color: 'var(--accent-primary)' },
    { icon: Image, label: 'Generate Image', desc: 'Create AI artwork', to: '/image-gen', color: 'var(--accent-green)' },
    { icon: TrendingUp, label: 'Upgrade Plan', desc: 'Unlock more features', to: '/pricing', color: 'var(--accent-amber)' },
  ];

  return (
    <div style={{ height: '100%', overflow: 'auto', background: 'var(--bg-base)' }}>
      <div style={{ maxWidth: 900, margin: '0 auto', padding: '32px 20px' }}>
        {/* Welcome */}
        <div style={{ marginBottom: 32, animation: 'fade-in 0.4s ease' }}>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 6 }}>
            Welcome back, {profile?.username ?? 'there'} 👋
          </h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: 15 }}>
            Here's a summary of your Nexora AI activity
          </p>
        </div>

        {/* Plan badge */}
        <div style={{
          background: 'var(--bg-surface)',
          border: '1px solid var(--border)',
          borderRadius: 'var(--radius-xl)',
          padding: '20px 24px',
          marginBottom: 24,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: 16,
          animation: 'fade-in 0.4s ease 0.05s both',
          position: 'relative',
          overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 1, background: `linear-gradient(90deg, transparent, ${planColor}, transparent)`, opacity: 0.4 }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 44, height: 44, borderRadius: '50%', background: `linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, fontWeight: 700, color: '#000' }}>
              {profile?.username?.[0]?.toUpperCase() ?? '?'}
            </div>
            <div>
              <div style={{ fontWeight: 600, fontSize: 15 }}>{profile?.username ?? user?.email}</div>
              <div style={{ fontSize: 13, color: planColor, fontWeight: 500, textTransform: 'capitalize' }}>
                {profile?.plan ?? 'free'} Plan
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 6 }}>Credits remaining</div>
              <div style={{ height: 6, width: 140, background: 'var(--bg-elevated)', borderRadius: 3, overflow: 'hidden' }}>
                <div style={{ height: '100%', width: `${creditsPercent}%`, background: `linear-gradient(90deg, ${planColor}, ${planColor}aa)`, borderRadius: 3, transition: 'width 1s ease' }} />
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 4 }}>{profile?.credits ?? 0} / 10 remaining</div>
            </div>
            <Link to="/pricing" style={{ padding: '8px 16px', background: 'rgba(0,212,255,0.08)', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 8, color: 'var(--accent-primary)', fontSize: 13, fontWeight: 500, display: 'flex', alignItems: 'center', gap: 6, transition: 'all var(--transition)', whiteSpace: 'nowrap' }}>
              Upgrade <ArrowRight size={13} />
            </Link>
          </div>
        </div>

        {/* Stats */}
        <div className="dashboard-stats-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 24, animation: 'fade-in 0.4s ease 0.1s both' }}>
          {statCards.map(({ label, value, icon: Icon, color, glow }) => (
            <div key={label} style={{
              background: 'var(--bg-surface)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-lg)',
              padding: '16px 20px',
              transition: 'border-color var(--transition)',
            }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = color; e.currentTarget.style.boxShadow = `0 0 20px ${glow}`; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.boxShadow = 'none'; }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                <div style={{ width: 32, height: 32, borderRadius: 8, background: `${color}12`, border: `1px solid ${color}25`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon size={16} color={color} />
                </div>
              </div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 2 }}>{value}</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{label}</div>
            </div>
          ))}
        </div>

        <div className="dashboard-bottom-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, animation: 'fade-in 0.4s ease 0.15s both' }}>
          {/* Quick actions */}
          <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-xl)', padding: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
              <Activity size={16} color="var(--accent-primary)" />
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, color: 'var(--text-primary)' }}>Quick Actions</h2>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {quickActions.map(({ icon: Icon, label, desc, to, color }) => (
                <Link
                  key={to}
                  to={to}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 12,
                    padding: '12px 14px', borderRadius: 'var(--radius-md)',
                    background: 'var(--bg-elevated)', border: '1px solid var(--border)',
                    transition: 'all var(--transition)',
                  }}
                  onMouseEnter={e => {
                    (e.currentTarget as HTMLAnchorElement).style.borderColor = color;
                    (e.currentTarget as HTMLAnchorElement).style.background = 'var(--bg-card)';
                  }}
                  onMouseLeave={e => {
                    (e.currentTarget as HTMLAnchorElement).style.borderColor = 'var(--border)';
                    (e.currentTarget as HTMLAnchorElement).style.background = 'var(--bg-elevated)';
                  }}
                >
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: `${color}12`, border: `1px solid ${color}25`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Icon size={17} color={color} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--text-primary)' }}>{label}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{desc}</div>
                  </div>
                  <ArrowRight size={14} color="var(--text-muted)" />
                </Link>
              ))}
            </div>
          </div>

          {/* Recent activity */}
          <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-xl)', padding: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
              <Clock size={16} color="var(--accent-green)" />
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, color: 'var(--text-primary)' }}>Recent Activity</h2>
            </div>
            {recentActivity.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '24px 0', color: 'var(--text-muted)', fontSize: 14 }}>
                No activity yet. Start chatting!
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {recentActivity.map((item, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 'var(--radius-md)', background: 'var(--bg-elevated)' }}>
                    <div style={{ width: 28, height: 28, borderRadius: 7, background: item.type === 'chat' ? 'rgba(0,212,255,0.1)' : 'rgba(0,255,136,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      {item.type === 'chat' ? <MessageSquare size={13} color="var(--accent-primary)" /> : <Image size={13} color="var(--accent-green)" />}
                    </div>
                    <div style={{ flex: 1, overflow: 'hidden' }}>
                      <div style={{ fontSize: 13, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.text}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{new Date(item.time).toLocaleDateString()}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <style>{`@media (max-width: 640px) { .stats-grid { grid-template-columns: repeat(2, 1fr) !important; } .actions-grid { grid-template-columns: 1fr !important; } }`}</style>
    </div>
  );
}
