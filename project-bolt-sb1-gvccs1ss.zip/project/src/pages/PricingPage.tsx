import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Check, X, Zap, Star, Building2, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const plans = [
  {
    name: 'Free',
    icon: Zap,
    price: { monthly: 0, yearly: 0 },
    color: 'var(--accent-primary)',
    glow: 'var(--accent-glow)',
    description: 'Perfect for getting started',
    features: [
      { text: '10 AI chat messages/month', included: true },
      { text: '5 image generations/month', included: true },
      { text: 'Basic chat history', included: true },
      { text: 'Standard response speed', included: true },
      { text: 'GPT-4 class models', included: false },
      { text: 'Priority support', included: false },
      { text: 'API access', included: false },
      { text: 'Custom personas', included: false },
    ],
    cta: 'Get Started Free',
    popular: false,
  },
  {
    name: 'Pro',
    icon: Star,
    price: { monthly: 19, yearly: 15 },
    color: 'var(--accent-green)',
    glow: 'var(--accent-green-glow)',
    description: 'For power users and creators',
    features: [
      { text: 'Unlimited AI chat messages', included: true },
      { text: '100 image generations/month', included: true },
      { text: 'Full chat history', included: true },
      { text: 'Faster response speed', included: true },
      { text: 'GPT-4 class models', included: true },
      { text: 'Priority support', included: true },
      { text: 'API access', included: false },
      { text: 'Custom personas', included: false },
    ],
    cta: 'Start Pro Trial',
    popular: true,
  },
  {
    name: 'Enterprise',
    icon: Building2,
    price: { monthly: 49, yearly: 39 },
    color: 'var(--accent-amber)',
    glow: 'rgba(255,170,0,0.15)',
    description: 'For teams and businesses',
    features: [
      { text: 'Unlimited AI chat messages', included: true },
      { text: 'Unlimited image generations', included: true },
      { text: 'Full chat history', included: true },
      { text: 'Fastest response speed', included: true },
      { text: 'GPT-4 class models', included: true },
      { text: 'Dedicated support', included: true },
      { text: 'Full API access', included: true },
      { text: 'Custom personas', included: true },
    ],
    cta: 'Contact Sales',
    popular: false,
  },
];

export function PricingPage() {
  const { session } = useAuth();
  const [yearly, setYearly] = useState(false);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-base)', padding: '0 16px', position: 'relative', overflow: 'hidden' }}>
      {/* Background glows */}
      <div style={{ position: 'absolute', top: '10%', left: '50%', transform: 'translateX(-50%)', width: 800, height: 500, background: 'radial-gradient(ellipse, rgba(0,212,255,0.04) 0%, transparent 70%)', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', bottom: '20%', right: '5%', width: 400, height: 400, background: 'radial-gradient(ellipse, rgba(0,255,136,0.03) 0%, transparent 70%)', pointerEvents: 'none' }} />

      {/* Nav */}
      <nav style={{ maxWidth: 1100, margin: '0 auto', padding: '20px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 16px var(--accent-glow)' }}>
            <Zap size={18} color="#000" />
          </div>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 20 }}>Nexora AI</span>
        </Link>
        <div style={{ display: 'flex', gap: 12 }}>
          {session ? (
            <Link to="/chat" style={{ padding: '9px 20px', background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))', borderRadius: 8, color: '#000', fontWeight: 600, fontSize: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
              <span>Open App</span><ArrowRight size={14} />
            </Link>
          ) : (
            <>
              <Link to="/login" style={{ padding: '9px 16px', color: 'var(--text-secondary)', fontSize: 14, borderRadius: 8, transition: 'color var(--transition)' }}>Sign In</Link>
              <Link to="/signup" style={{ padding: '9px 20px', background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))', borderRadius: 8, color: '#000', fontWeight: 600, fontSize: 14 }}>Get Started</Link>
            </>
          )}
        </div>
      </nav>

      <div style={{ maxWidth: 1100, margin: '0 auto', paddingBottom: 80 }}>
        {/* Header */}
        <div style={{ textAlign: 'center', padding: '60px 0 48px', animation: 'fade-in 0.5s ease' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 14px', background: 'rgba(0,212,255,0.08)', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 20, fontSize: 13, color: 'var(--accent-primary)', fontWeight: 500, marginBottom: 20 }}>
            <Star size={13} />
            Simple, transparent pricing
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 48, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 16, lineHeight: 1.15 }}>
            Choose your plan
          </h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: 18, maxWidth: 500, margin: '0 auto 32px' }}>
            Start free, scale as you grow. No hidden fees.
          </p>

          {/* Toggle */}
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 12, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 100, padding: '6px 8px' }}>
            <button
              onClick={() => setYearly(false)}
              style={{ padding: '7px 18px', borderRadius: 100, fontSize: 14, fontWeight: 500, transition: 'all var(--transition)', background: !yearly ? 'var(--bg-elevated)' : 'transparent', color: !yearly ? 'var(--text-primary)' : 'var(--text-muted)', border: !yearly ? '1px solid var(--border)' : '1px solid transparent' }}
            >
              Monthly
            </button>
            <button
              onClick={() => setYearly(true)}
              style={{ padding: '7px 18px', borderRadius: 100, fontSize: 14, fontWeight: 500, transition: 'all var(--transition)', background: yearly ? 'var(--bg-elevated)' : 'transparent', color: yearly ? 'var(--text-primary)' : 'var(--text-muted)', border: yearly ? '1px solid var(--border)' : '1px solid transparent', display: 'flex', alignItems: 'center', gap: 6 }}
            >
              Yearly
              <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--accent-green)', background: 'rgba(0,255,136,0.1)', padding: '2px 6px', borderRadius: 10 }}>-20%</span>
            </button>
          </div>
        </div>

        {/* Plans grid */}
        <div className="pricing-plans-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, animation: 'fade-in 0.5s ease 0.1s both' }}>
          {plans.map((plan) => {
            const PlanIcon = plan.icon;
            const price = yearly ? plan.price.yearly : plan.price.monthly;
            return (
              <div
                key={plan.name}
                style={{
                  background: plan.popular ? 'var(--bg-card)' : 'var(--bg-surface)',
                  border: plan.popular ? `1px solid ${plan.color}40` : '1px solid var(--border)',
                  borderRadius: 'var(--radius-xl)',
                  padding: '28px',
                  position: 'relative',
                  overflow: 'hidden',
                  transition: 'transform var(--transition), box-shadow var(--transition)',
                  boxShadow: plan.popular ? `0 0 40px ${plan.glow}` : 'none',
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.transform = 'translateY(-4px)';
                  if (!plan.popular) e.currentTarget.style.boxShadow = `0 12px 40px rgba(0,0,0,0.3)`;
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  if (!plan.popular) e.currentTarget.style.boxShadow = plan.popular ? `0 0 40px ${plan.glow}` : 'none';
                }}
              >
                {/* Top gradient line */}
                <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${plan.color}, transparent)`, opacity: plan.popular ? 1 : 0.4 }} />

                {plan.popular && (
                  <div style={{ position: 'absolute', top: 14, right: 14, background: `${plan.color}20`, border: `1px solid ${plan.color}40`, borderRadius: 20, padding: '3px 10px', fontSize: 11, fontWeight: 700, color: plan.color, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                    Most Popular
                  </div>
                )}

                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
                  <div style={{ width: 40, height: 40, borderRadius: 12, background: `${plan.color}15`, border: `1px solid ${plan.color}30`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `0 0 16px ${plan.glow}` }}>
                    <PlanIcon size={20} color={plan.color} />
                  </div>
                  <div>
                    <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: 'var(--text-primary)' }}>{plan.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{plan.description}</div>
                  </div>
                </div>

                <div style={{ marginBottom: 24 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: 40, fontWeight: 700, color: 'var(--text-primary)' }}>
                      ${price}
                    </span>
                    <span style={{ color: 'var(--text-muted)', fontSize: 14 }}>/mo</span>
                  </div>
                  {yearly && price > 0 && (
                    <div style={{ fontSize: 12, color: 'var(--accent-green)', marginTop: 2 }}>
                      Billed ${price * 12}/year — save ${(plan.price.monthly - price) * 12}/yr
                    </div>
                  )}
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 28 }}>
                  {plan.features.map(feat => (
                    <div key={feat.text} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ width: 18, height: 18, borderRadius: '50%', background: feat.included ? `${plan.color}15` : 'rgba(74,90,106,0.1)', border: `1px solid ${feat.included ? plan.color + '30' : 'rgba(74,90,106,0.2)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        {feat.included ? <Check size={10} color={plan.color} /> : <X size={10} color="var(--text-muted)" />}
                      </div>
                      <span style={{ fontSize: 13, color: feat.included ? 'var(--text-primary)' : 'var(--text-muted)' }}>{feat.text}</span>
                    </div>
                  ))}
                </div>

                <Link
                  to={session ? '/chat' : '/signup'}
                  style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                    width: '100%', padding: '12px',
                    background: plan.popular ? `linear-gradient(135deg, ${plan.color}, ${plan.color}bb)` : 'transparent',
                    border: plan.popular ? 'none' : `1px solid ${plan.color}40`,
                    borderRadius: 'var(--radius-md)',
                    color: plan.popular ? '#000' : plan.color,
                    fontWeight: 600, fontSize: 14,
                    transition: 'all var(--transition)',
                    boxShadow: plan.popular ? `0 0 20px ${plan.glow}` : 'none',
                  }}
                  onMouseEnter={e => {
                    if (!plan.popular) {
                      (e.currentTarget as HTMLAnchorElement).style.background = `${plan.color}12`;
                    }
                  }}
                  onMouseLeave={e => {
                    if (!plan.popular) {
                      (e.currentTarget as HTMLAnchorElement).style.background = 'transparent';
                    }
                  }}
                >
                  {plan.cta}
                  <ArrowRight size={14} />
                </Link>
              </div>
            );
          })}
        </div>

        {/* FAQ / trust signals */}
        <div style={{ marginTop: 80, textAlign: 'center' }}>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 48, flexWrap: 'wrap' }}>
            {['Cancel anytime', 'No credit card to start', '24/7 AI availability', 'SOC 2 compliant'].map(item => (
              <div key={item} style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--text-secondary)', fontSize: 14 }}>
                <Check size={16} color="var(--accent-green)" />
                {item}
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`@media (max-width: 768px) { .pricing-grid { grid-template-columns: 1fr !important; } }`}</style>
    </div>
  );
}
