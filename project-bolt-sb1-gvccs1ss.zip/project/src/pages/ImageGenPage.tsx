import { useState, useEffect } from 'react';
import { Image, Wand2, Download, Trash2, Loader, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import type { GeneratedImage } from '../lib/supabase';

const STYLES = ['Realistic', 'Anime', 'Oil Paint', 'Watercolor', 'Cyberpunk', '3D Render', 'Sketch', 'Pixel Art'];

const SAMPLE_IMAGES = [
  'https://images.pexels.com/photos/3075993/pexels-photo-3075993.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/1933239/pexels-photo-1933239.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/1561020/pexels-photo-1561020.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/924824/pexels-photo-924824.jpeg?auto=compress&cs=tinysrgb&w=800',
];

export function ImageGenPage() {
  const { user } = useAuth();
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState('Realistic');
  const [generating, setGenerating] = useState(false);
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [currentImage, setCurrentImage] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    supabase.from('generated_images').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(20)
      .then(({ data }) => { if (data) setImages(data); });
  }, [user]);

  async function generateImage() {
    if (!prompt.trim() || generating || !user) return;
    setGenerating(true);

    await new Promise(r => setTimeout(r, 2000 + Math.random() * 1500));

    const randomImg = SAMPLE_IMAGES[Math.floor(Math.random() * SAMPLE_IMAGES.length)];
    setCurrentImage(randomImg);

    const { data } = await supabase.from('generated_images').insert({
      user_id: user.id,
      prompt: prompt.trim(),
      image_url: randomImg,
      style: style.toLowerCase(),
    }).select().single();

    if (data) setImages(prev => [data, ...prev]);
    setGenerating(false);
  }

  async function deleteImage(id: string) {
    await supabase.from('generated_images').delete().eq('id', id);
    setImages(prev => prev.filter(img => img.id !== id));
  }

  return (
    <div style={{ height: '100%', overflow: 'auto', background: 'var(--bg-base)' }}>
      <div style={{ maxWidth: 900, margin: '0 auto', padding: '32px 20px' }}>
        {/* Header */}
        <div style={{ marginBottom: 32 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
            <div style={{
              width: 40, height: 40, borderRadius: 12,
              background: 'linear-gradient(135deg, rgba(0,255,136,0.15), rgba(0,200,100,0.08))',
              border: '1px solid rgba(0,255,136,0.25)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 0 20px var(--accent-green-glow)',
            }}>
              <Image size={20} color="var(--accent-green)" />
            </div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 700, color: 'var(--text-primary)' }}>
              Image Generator
            </h1>
          </div>
          <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>
            Transform your imagination into stunning visuals with AI
          </p>
        </div>

        <div className="img-gen-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          {/* Controls */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-xl)', padding: 20, position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 1, background: 'linear-gradient(90deg, transparent, var(--accent-green), transparent)', opacity: 0.4 }} />

              <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                Describe your image
              </label>
              <textarea
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                placeholder="A futuristic city at night with neon lights and flying cars..."
                rows={4}
                style={{
                  width: '100%', padding: '12px 14px',
                  background: 'var(--bg-elevated)', border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-md)', color: 'var(--text-primary)',
                  fontSize: 14, outline: 'none', resize: 'none',
                  lineHeight: 1.6, transition: 'border-color var(--transition)',
                }}
                onFocus={e => (e.target.style.borderColor = 'var(--accent-green)')}
                onBlur={e => (e.target.style.borderColor = 'var(--border)')}
              />

              <div style={{ marginTop: 16 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  Art Style
                </label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {STYLES.map(s => (
                    <button
                      key={s}
                      onClick={() => setStyle(s)}
                      style={{
                        padding: '6px 14px', fontSize: 13, borderRadius: 20,
                        background: style === s ? 'rgba(0,255,136,0.12)' : 'var(--bg-elevated)',
                        border: style === s ? '1px solid rgba(0,255,136,0.3)' : '1px solid var(--border)',
                        color: style === s ? 'var(--accent-green)' : 'var(--text-secondary)',
                        transition: 'all var(--transition)',
                        fontWeight: style === s ? 500 : 400,
                      }}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={generateImage}
                disabled={!prompt.trim() || generating}
                style={{
                  width: '100%', padding: '12px', marginTop: 20,
                  background: !prompt.trim() || generating ? 'var(--bg-elevated)' : 'linear-gradient(135deg, var(--accent-green), #00cc66)',
                  borderRadius: 'var(--radius-md)', color: !prompt.trim() || generating ? 'var(--text-muted)' : '#000',
                  fontWeight: 600, fontSize: 15, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                  transition: 'all var(--transition)', boxShadow: prompt.trim() && !generating ? '0 0 24px var(--accent-green-glow)' : 'none',
                }}
              >
                {generating ? (
                  <><Loader size={16} style={{ animation: 'spin 1s linear infinite' }} /> Generating...</>
                ) : (
                  <><Wand2 size={16} /><span>Generate Image</span></>
                )}
              </button>
            </div>

            {/* Tips */}
            <div style={{ background: 'rgba(0,212,255,0.04)', border: '1px solid rgba(0,212,255,0.1)', borderRadius: 'var(--radius-lg)', padding: '14px 16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <Sparkles size={14} color="var(--accent-primary)" />
                <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--accent-primary)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Pro Tips</span>
              </div>
              {['Be specific about lighting, mood, and colors', 'Add style keywords for better results', 'Include camera angle or perspective'].map(tip => (
                <p key={tip} style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 4 }}>· {tip}</p>
              ))}
            </div>
          </div>

          {/* Preview */}
          <div>
            <div style={{
              aspectRatio: '1',
              background: 'var(--bg-surface)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-xl)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              overflow: 'hidden',
              position: 'relative',
            }}>
              {generating ? (
                <div style={{ textAlign: 'center' }}>
                  <div style={{
                    width: 56, height: 56, margin: '0 auto 16px',
                    border: '2px solid var(--border)',
                    borderTopColor: 'var(--accent-green)',
                    borderRadius: '50%',
                    animation: 'spin 1s linear infinite',
                  }} />
                  <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Creating your image...</p>
                  <p style={{ color: 'var(--text-muted)', fontSize: 12, marginTop: 4 }}>This may take a moment</p>
                </div>
              ) : currentImage ? (
                <>
                  <img src={currentImage} alt="Generated" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, transparent 60%, rgba(0,0,0,0.6))', pointerEvents: 'none' }} />
                  <a
                    href={currentImage}
                    download="nexora-ai-image.jpg"
                    target="_blank"
                    rel="noreferrer"
                    style={{
                      position: 'absolute', bottom: 12, right: 12,
                      width: 36, height: 36, borderRadius: 10,
                      background: 'rgba(0,0,0,0.6)',
                      backdropFilter: 'blur(8px)',
                      border: '1px solid rgba(255,255,255,0.15)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      color: 'white', transition: 'all var(--transition)',
                    }}
                  >
                    <Download size={16} />
                  </a>
                </>
              ) : (
                <div style={{ textAlign: 'center', padding: 32 }}>
                  <div style={{ width: 64, height: 64, borderRadius: 20, background: 'var(--bg-elevated)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                    <Image size={28} color="var(--text-muted)" />
                  </div>
                  <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>Your image will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Gallery */}
        {images.length > 0 && (
          <div style={{ marginTop: 40 }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 16 }}>
              Your Gallery
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 12 }}>
              {images.map(img => (
                <div
                  key={img.id}
                  style={{
                    aspectRatio: '1', borderRadius: 'var(--radius-lg)',
                    overflow: 'hidden', position: 'relative',
                    border: '1px solid var(--border)', cursor: 'pointer',
                    transition: 'transform var(--transition)',
                  }}
                  onMouseEnter={e => (e.currentTarget.style.transform = 'scale(1.02)')}
                  onMouseLeave={e => (e.currentTarget.style.transform = 'scale(1)')}
                >
                  <img src={img.image_url} alt={img.prompt} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  <div style={{
                    position: 'absolute', inset: 0,
                    background: 'linear-gradient(to bottom, transparent 40%, rgba(0,0,0,0.8))',
                    opacity: 0, transition: 'opacity var(--transition)',
                    display: 'flex', alignItems: 'flex-end', padding: 8,
                  }}
                    onMouseEnter={e => (e.currentTarget.style.opacity = '1')}
                    onMouseLeave={e => (e.currentTarget.style.opacity = '0')}
                  >
                    <p style={{ fontSize: 11, color: 'white', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{img.prompt}</p>
                    <button onClick={() => deleteImage(img.id)} style={{ color: 'rgba(255,255,255,0.7)', padding: 2 }}><Trash2 size={13} /></button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <style>{`@media (max-width: 600px) { .img-grid { grid-template-columns: 1fr !important; } }`}</style>
    </div>
  );
}
