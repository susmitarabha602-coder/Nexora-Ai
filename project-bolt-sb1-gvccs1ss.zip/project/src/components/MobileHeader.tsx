import { Link } from 'react-router-dom';
import { Menu, Zap } from 'lucide-react';

export function MobileHeader({ onMenuClick }: { onMenuClick: () => void }) {
  return (
    <header style={{
      height: 56,
      display: 'none',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 16px',
      borderBottom: '1px solid var(--border)',
      background: 'var(--bg-surface)',
      flexShrink: 0,
    }} className="mobile-header">
      <button
        onClick={onMenuClick}
        style={{ color: 'var(--text-secondary)', padding: 8, borderRadius: 8 }}
      >
        <Menu size={20} />
      </button>
      <Link to="/chat" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{
          width: 28,
          height: 28,
          borderRadius: 7,
          background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 0 12px var(--accent-glow)',
        }}>
          <Zap size={15} color="#000" />
        </div>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17 }}>Nexora AI</span>
      </Link>
      <div style={{ width: 36 }} />
      <style>{`@media (max-width: 767px) { .mobile-header { display: flex !important; } }`}</style>
    </header>
  );
}
