import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  MessageSquare, Image, LayoutDashboard, CreditCard,
  Plus, Trash2, X, Zap, LogOut, ChevronRight
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import type { ChatConversation } from '../lib/supabase';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/dashboard' },
  { icon: MessageSquare, label: 'AI Chat', path: '/chat' },
  { icon: Image, label: 'Image Gen', path: '/image-gen' },
  { icon: CreditCard, label: 'Pricing', path: '/pricing' },
];

export function Sidebar({ onClose }: { onClose: () => void }) {
  const { user, profile, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [conversations, setConversations] = useState<ChatConversation[]>([]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('chat_conversations')
      .select('*')
      .eq('user_id', user.id)
      .order('updated_at', { ascending: false })
      .limit(20)
      .then(({ data }) => { if (data) setConversations(data); });
  }, [user]);

  async function newChat() {
    navigate('/chat');
    onClose();
  }

  async function deleteConversation(e: React.MouseEvent, id: string) {
    e.preventDefault();
    e.stopPropagation();
    await supabase.from('chat_conversations').delete().eq('id', id);
    setConversations(prev => prev.filter(c => c.id !== id));
    if (location.pathname === `/chat/${id}`) navigate('/chat');
  }

  async function handleSignOut() {
    await signOut();
    navigate('/login');
  }

  const planColor = profile?.plan === 'pro' ? 'var(--accent-green)' : profile?.plan === 'enterprise' ? 'var(--accent-amber)' : 'var(--accent-primary)';

  return (
    <div style={{
      width: 'var(--sidebar-width)',
      height: '100vh',
      background: 'var(--bg-surface)',
      borderRight: '1px solid var(--border)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      position: 'relative',
    }}>
      {/* Glow accent */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: 1,
        background: 'linear-gradient(90deg, transparent, var(--accent-primary), transparent)',
        opacity: 0.6,
      }} />

      {/* Logo */}
      <div style={{
        padding: '20px 16px 16px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderBottom: '1px solid var(--border)',
      }}>
        <Link to="/chat" style={{ display: 'flex', alignItems: 'center', gap: 10 }} onClick={onClose}>
          <div style={{
            width: 32,
            height: 32,
            borderRadius: 8,
            background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 0 16px var(--accent-glow)',
          }}>
            <Zap size={18} color="#000" />
          </div>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18, letterSpacing: '-0.3px', color: 'var(--text-primary)' }}>
            Nexora AI
          </span>
        </Link>
        <button
          onClick={onClose}
          className="md-hide"
          style={{ color: 'var(--text-muted)', padding: 4, borderRadius: 6, transition: 'color var(--transition)' }}
        >
          <X size={18} />
        </button>
      </div>

      {/* New Chat */}
      <div style={{ padding: '12px 12px 8px' }}>
        <button
          onClick={newChat}
          style={{
            width: '100%',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            padding: '10px 14px',
            borderRadius: 'var(--radius-md)',
            background: 'linear-gradient(135deg, rgba(0,212,255,0.12), rgba(0,153,204,0.08))',
            border: '1px solid rgba(0,212,255,0.2)',
            color: 'var(--accent-primary)',
            fontSize: 14,
            fontWeight: 500,
            transition: 'all var(--transition)',
          }}
          onMouseEnter={e => {
            (e.currentTarget as HTMLButtonElement).style.background = 'linear-gradient(135deg, rgba(0,212,255,0.2), rgba(0,153,204,0.14))';
            (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 0 20px var(--accent-glow)';
          }}
          onMouseLeave={e => {
            (e.currentTarget as HTMLButtonElement).style.background = 'linear-gradient(135deg, rgba(0,212,255,0.12), rgba(0,153,204,0.08))';
            (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none';
          }}
        >
          <Plus size={16} />
          New Conversation
        </button>
      </div>

      {/* Navigation */}
      <nav style={{ padding: '4px 12px 8px' }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '4px 2px 8px' }}>
          Navigation
        </div>
        {navItems.map(({ icon: Icon, label, path }) => {
          const active = location.pathname === path || (path === '/chat' && location.pathname.startsWith('/chat'));
          return (
            <Link
              key={path}
              to={path}
              onClick={onClose}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                padding: '9px 12px',
                borderRadius: 'var(--radius-md)',
                color: active ? 'var(--accent-primary)' : 'var(--text-secondary)',
                background: active ? 'rgba(0,212,255,0.08)' : 'transparent',
                border: active ? '1px solid rgba(0,212,255,0.12)' : '1px solid transparent',
                fontSize: 14,
                fontWeight: active ? 500 : 400,
                transition: 'all var(--transition)',
                marginBottom: 2,
              }}
              onMouseEnter={e => {
                if (!active) (e.currentTarget as HTMLAnchorElement).style.background = 'var(--bg-hover)';
              }}
              onMouseLeave={e => {
                if (!active) (e.currentTarget as HTMLAnchorElement).style.background = 'transparent';
              }}
            >
              <Icon size={16} />
              {label}
              {active && <ChevronRight size={14} style={{ marginLeft: 'auto', opacity: 0.5 }} />}
            </Link>
          );
        })}
      </nav>

      {/* Recent Chats */}
      {conversations.length > 0 && (
        <div style={{ flex: 1, overflow: 'auto', padding: '4px 12px' }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '4px 2px 8px' }}>
            Recent Chats
          </div>
          {conversations.map(conv => {
            const active = location.pathname === `/chat/${conv.id}`;
            return (
              <Link
                key={conv.id}
                to={`/chat/${conv.id}`}
                onClick={onClose}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '8px 10px',
                  borderRadius: 'var(--radius-sm)',
                  color: active ? 'var(--text-primary)' : 'var(--text-secondary)',
                  background: active ? 'var(--bg-elevated)' : 'transparent',
                  fontSize: 13,
                  transition: 'all var(--transition)',
                  marginBottom: 1,
                }}
                onMouseEnter={e => {
                  if (!active) (e.currentTarget as HTMLAnchorElement).style.background = 'var(--bg-elevated)';
                  const btn = e.currentTarget.querySelector('button') as HTMLButtonElement;
                  if (btn) btn.style.opacity = '1';
                }}
                onMouseLeave={e => {
                  if (!active) (e.currentTarget as HTMLAnchorElement).style.background = 'transparent';
                  const btn = e.currentTarget.querySelector('button') as HTMLButtonElement;
                  if (btn) btn.style.opacity = '0';
                }}
              >
                <MessageSquare size={12} style={{ flexShrink: 0, opacity: 0.6 }} />
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>
                  {conv.title}
                </span>
                <button
                  onClick={e => deleteConversation(e, conv.id)}
                  style={{ opacity: 0, transition: 'opacity var(--transition)', color: 'var(--text-muted)', padding: 2, borderRadius: 4 }}
                  onMouseEnter={e => (e.currentTarget.style.color = 'var(--accent-red)')}
                  onMouseLeave={e => (e.currentTarget.style.color = 'var(--text-muted)')}
                >
                  <Trash2 size={12} />
                </button>
              </Link>
            );
          })}
        </div>
      )}

      {/* User profile */}
      <div style={{
        padding: '12px',
        borderTop: '1px solid var(--border)',
        marginTop: 'auto',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          padding: '10px 12px',
          borderRadius: 'var(--radius-md)',
          background: 'var(--bg-card)',
          border: '1px solid var(--border)',
        }}>
          <div style={{
            width: 32,
            height: 32,
            borderRadius: '50%',
            background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 13,
            fontWeight: 600,
            color: '#000',
            flexShrink: 0,
          }}>
            {profile?.username?.[0]?.toUpperCase() ?? user?.email?.[0]?.toUpperCase() ?? 'U'}
          </div>
          <div style={{ flex: 1, overflow: 'hidden' }}>
            <div style={{ fontSize: 13, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {profile?.username ?? user?.email?.split('@')[0] ?? 'User'}
            </div>
            <div style={{ fontSize: 11, color: planColor, fontWeight: 500, textTransform: 'capitalize' }}>
              {profile?.plan ?? 'free'} · {profile?.credits ?? 0} credits
            </div>
          </div>
          <button
            onClick={handleSignOut}
            style={{ color: 'var(--text-muted)', padding: 4, borderRadius: 6, transition: 'color var(--transition)' }}
            title="Sign out"
            onMouseEnter={e => (e.currentTarget.style.color = 'var(--accent-red)')}
            onMouseLeave={e => (e.currentTarget.style.color = 'var(--text-muted)')}
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>

      <style>{`.md-hide { display: block; } @media (min-width: 768px) { .md-hide { display: none !important; } }`}</style>
    </div>
  );
}
